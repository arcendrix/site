---
title: About
permalink: /about/
---

Arcendrix is built for operators.

We design control layers that reduce friction, protect margin, and restore visibility—without enterprise bloat.

If your business runs on spreadsheets, whiteboards, and memory, we should talk.

{% include cta.html %}
