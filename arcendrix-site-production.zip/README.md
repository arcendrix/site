# Arcendrix — Jekyll + GitHub Pages (Production)

## Deploy on GitHub Pages
Settings → Pages → Deploy from branch → main / root

### If using PROJECT pages (username.github.io/arcendrix-site)
Set in `_config.yml`:
- url: "https://YOUR_GITHUB_USERNAME.github.io"
- baseurl: "/arcendrix-site"

### If using USER pages (YOUR_GITHUB_USERNAME.github.io)
Keep:
- url: "https://YOUR_GITHUB_USERNAME.github.io"
- baseurl: ""

## Local run (optional)
1) Install Ruby + Bundler
2) bundle install
3) bundle exec jekyll serve
