---
title: Work
permalink: /work/
---

We build systems that get used daily.

## Example deliverables
- Job status boards (operator-grade)
- Field logs that sync to office in real time
- Cost + margin visibility
- Equipment utilization snapshots
- Invoice/report generation

If you want, publish anonymized case studies once your first system is live.

{% include cta.html %}
